//
//  Server.hpp
//  SQL_server
//
//  Created by Дарья on 06.04.2021.
//

#ifndef Server_hpp
#define Server_hpp


#include <iostream>
#include <string>
#include <fstream>
#define MaxFieldNameLen 30

typedef struct Table * THandle;

enum FieldType
{
    Text, /* строка ( не более 256 символов) */
    Long, /* целое длинное знаковое число */
};

enum Direction
{
    LINK_PREV,
    LINK_NEXT
};

struct FieldDef
{
    std::string name = "\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0";//MaxFieldNameLen);//, '\0'); /* имя данного поля */
    enum FieldType type; /* тип поля */
    unsigned len; /* длина поля в байтах */
};

struct TableStruct  // first row of columns
{
    unsigned numOfFields; /* число полей в таблице */
    struct FieldDef *fieldsDef; /* динамический массив,
каждый элемент которого - описание поля таблицы */
};




struct FieldStruct
{
    std::string fieldName = "\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0";// [MaxFieldNameLen];
    enum FieldType type;
    long len;
    char * pNewValue; // put long & text here
    char * pEditValue;
};

extern std::string FILE_SIGNATURE;

extern std::string ErrorText[];

enum Errors /* Определяет возможные коды ошибок при работе с таблицами */
{
OK, /* Ошибок нет */
CantCreateTable,
CantOpenTable,
FieldNotFound,
BadHandle,
BadArgs,
CantMoveToPos,
CantWriteData,
CantReadData,
CorruptedData,
CantCreateHandle,
ReadOnlyFile,
BadFileName,
CantDeleteTable,
CorruptedFile,
BadPos,
BadFieldType,
BadFieldLen,
NoEditing,
BadPosition,
};

struct Table
{
public:
    std::fstream* f;
    FieldStruct * pFieldStruct;
    struct TableInfo
    {
        long dataOffset;
        long fieldNumber; /* duplicates pFieldStruct->numOfFields */
        long recordSize;
        long totalRecordNumber; /* including deleted records */
        long recordNumber;
        long firstRecordOffset;
        long lastRecordOffset;
        long firstDeletedOffset;
    } tableInfo;
    long currentPos;
    bool editFlag;
    struct links
    {
        long prevOffset;
        long nextOffset;
    } links;
public:

};


class TableHandle
{
public:
    static enum Errors createTable(const char* tableName, struct TableStruct *tableStruct)
    {
        enum Errors retval;

        if (tableName == "" || !tableStruct) return BadArgs;

        std::fstream f;
        try
        {
            f.open(tableName, std::ofstream::out | std::ofstream::binary |  std::ofstream::in | std::fstream::trunc);
        }
        catch (std::ios_base::failure& e)
        {
            std::cout << e.what() << '\n';
            switch(errno) {
            case EACCES: return ReadOnlyFile;
            case ENOENT: return BadFileName;
            default:
                return CantCreateTable;
            }
        }

        if (tableStruct->numOfFields <= 0 || !tableStruct->fieldsDef) return CorruptedData;

        Table * THandle = CreateTableHandle (tableStruct);
        if (!THandle)
        {
            f.close();
            return CantCreateHandle;
        }
        
        THandle->f = &f;
        retval = WriteHeader (THandle);
        DeleteTableHandle (THandle);
        
        return retval;
    }
    
    static enum Errors deleteTable(char* tableName)
    {
        if (!tableName)
            return BadArgs;
        if (!remove (tableName))
            return OK;
        switch(errno) {
        case EACCES : return ReadOnlyFile;
        case ENOENT : return BadFileName;
        default : return CantDeleteTable;
        }
    }
    
    static enum Errors openTable(std::string tableName, THandle *tableHandle)
    {
        std::fstream f;
        enum Errors retval;
        struct Table * tabHandle;

        //if (!tableName || !tableHandle) return BadArgs;

        *tableHandle = NULL;

        try
        {
            f.open(tableName, std::fstream::out | std::fstream::binary | std::fstream::in);
        }
        catch (std::ios_base::failure& e)
        {
            std::cout << e.what() << '\n';
            switch(errno) {
            case EACCES: return ReadOnlyFile;
            case ENOENT: return BadFileName;
            default:
                return CantOpenTable;
            }
        }
        //Table * THandle = CreateTableHandle (tableStruct);
        tabHandle = AllocateTableHandle ();
        if (!tabHandle)
        {
            f.close();
            return CantOpenTable;
        }
        tabHandle->f = &f;
        tabHandle->f->write("qwer", 5);
        retval = ReadHeader (tabHandle);
        if (retval != OK) {
            DeleteTableHandle (tabHandle);
            return retval;
        }

        retval = AllocateBuffers (tabHandle);
        if (retval != OK)
        {
            DeleteTableHandle (tabHandle);
            return retval;
        }

        tabHandle->currentPos = tabHandle->tableInfo.firstRecordOffset;

        if (tabHandle->currentPos >= tabHandle->tableInfo.dataOffset)  {
            retval = GetCurrentRecord (tabHandle);
            if (retval != OK) {
                DeleteTableHandle (tabHandle);
                return retval;
            }
        }

        *tableHandle = tabHandle;
        return OK;
    }
    
    static enum Errors closeTable(THandle tableHandle)
    {
        enum Errors retval = OK;

        if (!tableHandle) return BadHandle;
        if (tableHandle->f->is_open())
        {
            tableHandle->f->write("qwer", 5);
            retval = WriteHeader (tableHandle);
        }
        DeleteTableHandle(tableHandle);
        return retval;
    }
    
    static enum Errors createNew(THandle tableHandle)
    {
        int i;
        if (!tableHandle) return BadHandle;
        for (i = 0; i < tableHandle->tableInfo.fieldNumber; i++)
        {
            memset (tableHandle->pFieldStruct[i].pNewValue, 0, tableHandle->pFieldStruct[i].len);
        }
        return OK;
    }
    
    static enum Errors putTextNew(THandle tableHandle, std::string fieldName, char* value)
    {
        int i;

        if (!tableHandle) return BadHandle;
        if (fieldName == "" || !value ) return BadArgs;

        for (i = 0; i < tableHandle->tableInfo.fieldNumber; i++)
            if (fieldName == tableHandle->pFieldStruct[i].fieldName)
            {
                if (tableHandle->pFieldStruct[i].type != Text) return BadFieldType;
                if ( strlen(value) >= (unsigned)tableHandle->pFieldStruct[i].len) return BadFieldLen;
                strcpy(tableHandle->pFieldStruct[i].pNewValue, value);
                return OK;
            }
        return FieldNotFound;
    }

    static enum Errors putLongNew(THandle tableHandle, char * fieldName, long value)
    {
        int i;

        if (!tableHandle) return BadHandle;
        if (!fieldName) return BadArgs;

        for (i = 0; i < tableHandle->tableInfo.fieldNumber; i++)
            if (fieldName == tableHandle->pFieldStruct[i].fieldName)
            {
                if (tableHandle->pFieldStruct[i].type != Long) return BadFieldType;
                memcpy (tableHandle->pFieldStruct[i].pNewValue, &value, sizeof (long));
                return OK;
            }
        return FieldNotFound;
    }
    
    static enum Errors insertNew(THandle tableHandle)
    {
        long position;
        struct Table::links links;
        enum Errors retval;

        if (!tableHandle || !(tableHandle->f->is_open())) return BadHandle;
        retval = GetInsertPos (tableHandle, &position);
        if (retval != OK) return retval;
        retval = GetLinks (tableHandle, tableHandle->links.prevOffset, &links);
        if (retval != OK) return retval;
        links.nextOffset = tableHandle->currentPos;
        if (links.nextOffset == -1) links.nextOffset = 0;
        retval = PutNewRecord (tableHandle, position, &links);
        if (retval != OK) return retval;
        retval = ModifyLinks (tableHandle, tableHandle->currentPos, position, LINK_PREV);
        if (retval != OK) return retval;
        retval = ModifyLinks (tableHandle, tableHandle->links.prevOffset, position, LINK_NEXT);
        if (retval != OK) return retval;
        if (tableHandle->tableInfo.recordNumber == 0) {
            tableHandle->tableInfo.firstRecordOffset = position;
            tableHandle->tableInfo.lastRecordOffset = position;
        } else if (tableHandle->links.prevOffset == -1) {
            tableHandle->tableInfo.firstRecordOffset = position;
        }
        tableHandle->tableInfo.recordNumber++;
        
        return OK;
    }
    
    static struct Table * CreateNewRecord (struct TableStruct * tableStruct)
    {
        struct Table * handle;
        handle = CreateTableHandle (tableStruct);
        AllocateBuffers (handle);
        return handle;
    }
    
    
    
    static struct Table * CreateTableHandle (struct TableStruct * tableStruct)
    {
        struct Table * handle;
        unsigned i;
        long RecSize = 0;
        handle = AllocateTableHandle ();
        if (!handle) return NULL;
        /* copy structure and count record size */
        handle->tableInfo.fieldNumber = tableStruct->numOfFields;
        handle->pFieldStruct = (FieldStruct *) calloc (tableStruct->numOfFields, sizeof (FieldStruct));
        if (!handle->pFieldStruct)
        {
            DeleteTableHandle (handle);
            return NULL;
        }
        for (i = 0; i < tableStruct->numOfFields; i++)
        {
            handle->pFieldStruct[i].fieldName = tableStruct->fieldsDef[i].name;
            handle->pFieldStruct[i].type = tableStruct->fieldsDef[i].type;
            switch(tableStruct->fieldsDef[i].type)
            {
            case Long:
                handle->pFieldStruct[i].len = sizeof (long);
                RecSize += sizeof (long);
                break;
            case Text:
                if (!tableStruct->fieldsDef[i].len)
                {
                    DeleteTableHandle (handle);
                    return NULL;
                }
                handle->pFieldStruct[i].len = tableStruct->fieldsDef[i].len+1;
                RecSize += tableStruct->fieldsDef[i].len+1;
                break;
            }
        }

        handle->tableInfo.recordSize = RecSize;
        handle->tableInfo.dataOffset = sizeof (FILE_SIGNATURE) +
            sizeof (struct Table::TableInfo) + handle->tableInfo.fieldNumber * sizeof (FieldStruct);

        return handle;
    }
    
#define MOVE_POS(pos) \
{\
    tabHandle->f->seekp(pos, std::ios::beg);\
}\
    
#define READ_DATA(buf,size) \
{\
    tabHandle->f->read(reinterpret_cast<char*>(buf), size);\
}\

#define WRITE_DATA(buf,size) \
{\
    tabHandle->f->write(reinterpret_cast<char*>(buf), size);\
}\

    
    static enum Errors WriteHeader (struct Table * tabHandle)
    {
        
        
        //tabHandle->f->seekp(0, std::ios::beg);
        try
        {
            MOVE_POS (0);
            WRITE_DATA (&FILE_SIGNATURE, sizeof(FILE_SIGNATURE));
            
            //tabHandle->f->write(reinterpret_cast<char*>(&FILE_SIGNATURE), sizeof(FILE_SIGNATURE));
            
            WRITE_DATA (&tabHandle->tableInfo, sizeof(struct Table::TableInfo));
            
            //tabHandle->f->write(reinterpret_cast<char*>(&tabHandle->tableInfo), sizeof(struct Table::TableInfo));
            if (tabHandle->pFieldStruct)
            {
                WRITE_DATA (tabHandle->pFieldStruct, sizeof (FieldStruct) * tabHandle->tableInfo.fieldNumber);
                
                //tabHandle->f->write(reinterpret_cast<char*>(tabHandle->pFieldStruct), sizeof (FieldStruct) * tabHandle->tableInfo.fieldNumber);
            }
            else
            {
              return CantWriteData;
            }
        }
        catch (std::ios_base::failure& e)
        {
            std::cout << e.what() << '\n';
            return CantWriteData;
        }
        return OK;
    }
    
    static void DeleteTableHandle (struct Table * tabHandle)
    {
        try {
            //tabHandle->f->close();
            
        }
        catch (std::ios_base::failure& e)
        {
            std::cout << e.what() << '\n';
        }
        DeallocateBuffers (tabHandle);
        free (tabHandle->pFieldStruct);
        free (tabHandle);
    }
    
    
    static struct Table * AllocateTableHandle ()
    {
        struct Table * handle;
        handle = (struct Table *) calloc (1, sizeof (struct Table));
        if (!handle) return NULL;
        handle->pFieldStruct = NULL;
        handle->currentPos = -1;
        handle->tableInfo.recordNumber = 0;
        handle->tableInfo.totalRecordNumber = 0;
        handle->tableInfo.firstRecordOffset = -1;
        handle->tableInfo.firstDeletedOffset = -1;
        handle->tableInfo.lastRecordOffset = 0;
        handle->tableInfo.fieldNumber = 0;
        handle->tableInfo.recordSize = 0;
        handle->tableInfo.dataOffset = 0;
        handle->links.prevOffset = -1;
        handle->links.nextOffset = 0;
        handle->editFlag = false;
        return handle;
    }
    
    static void DeallocateBuffers (struct Table * tabHandle)
    {
        int i;

        if (!tabHandle->pFieldStruct) return;
        for (i = 0; i < tabHandle->tableInfo.fieldNumber; i++)
        {
            if (tabHandle->pFieldStruct[i].pNewValue) free(tabHandle->pFieldStruct[i].pNewValue);
            if (tabHandle->pFieldStruct[i].pEditValue) free(tabHandle->pFieldStruct[i].pEditValue);
        }
    }
    
    static enum Errors GetCurrentRecord (struct Table * tabHandle)
    {
        int i;
        if (tabHandle->currentPos < tabHandle->tableInfo.dataOffset)
        {
            return BadPos;
        }
        MOVE_POS (tabHandle->currentPos);
        //f.read(reinterpret_cast<char*>(&(tabHandle->links)), sizeof (tabHandle->links));
        READ_DATA (&(tabHandle->links), sizeof (tabHandle->links));
        for (i = 0; i < tabHandle->tableInfo.fieldNumber; i++)
        {
            READ_DATA (tabHandle->pFieldStruct[i].pEditValue, tabHandle->pFieldStruct[i].len);
        }
        return OK;
    }
    
    static enum Errors PutCurrentRecord (struct Table * tabHandle)
    {
        int i;
        MOVE_POS (tabHandle->currentPos);
        WRITE_DATA (&tabHandle->links, sizeof(struct Table::links));
        for (i = 0; i < tabHandle->tableInfo.fieldNumber; i++)
        {
            WRITE_DATA (tabHandle->pFieldStruct[i].pEditValue, tabHandle->pFieldStruct[i].len);
        }
        return OK;
    }
    
    static enum Errors PutNewRecord (struct Table * tabHandle, long position, struct Table::links * links)
    {
        int i;
        MOVE_POS (position);
        WRITE_DATA (links, sizeof (struct Table::links));
        for (i = 0; i < tabHandle->tableInfo.fieldNumber; i++)
        {
            WRITE_DATA (tabHandle->pFieldStruct[i].pNewValue, tabHandle->pFieldStruct[i].len);
        }
        return OK;
    }

    static enum Errors ModifyLinks (struct Table *  tabHandle, long position, long value, enum Direction dir)
    {
        long posToWrite = 0;

        if (position != 0 && position != -1)
        {
            switch (dir)
            {
            case LINK_PREV: posToWrite = position;
                break;
            case LINK_NEXT: posToWrite = position + sizeof (long);
                break;
            }
            MOVE_POS (posToWrite);
            WRITE_DATA (&value, sizeof (value));
        }
        return OK;
    }
    
    static enum Errors GetInsertPos (struct Table * tabHandle, long * position)
    {
        struct Table::links links;
        if (tabHandle->tableInfo.firstDeletedOffset >= tabHandle->tableInfo.dataOffset)
        {
            *position = tabHandle->tableInfo.firstDeletedOffset;
            MOVE_POS (*position);
            READ_DATA (&links, sizeof (struct Table::links));
            if (links.prevOffset != -1)
            {
                return CorruptedFile;
            }
            tabHandle->tableInfo.firstDeletedOffset = links.nextOffset;
        }
        else
        {
            /* no deleted records - position at the end of file */
            *position = tabHandle->tableInfo.dataOffset + tabHandle->tableInfo.totalRecordNumber *
                      (tabHandle->tableInfo.recordSize + sizeof (struct Table::links));
            MOVE_POS (*position);
            tabHandle->tableInfo.totalRecordNumber++;
        }
        return OK;
    }
    
    static enum Errors GetLinks (struct Table * tabHandle, long position, struct Table::links * links)
    {
        if (position == 0 || position == -1)
        {
            links->prevOffset = -1;
            links->nextOffset = 0;
        }
        else
        {
          MOVE_POS (position);
          READ_DATA (links, sizeof (struct Table::links));
        }
        return OK;
    }
    
    static enum Errors ReadHeader (struct Table * tabHandle)
    {
        std::string FileSig = "123456789012";
        //char FileSig[sizeof(FILE_SIGNATURE)];
        MOVE_POS (0);
        READ_DATA (&FileSig, sizeof (FILE_SIGNATURE));
        if (FileSig != FILE_SIGNATURE)
        {
            return CorruptedFile;
        }
        READ_DATA (&tabHandle->tableInfo, sizeof (struct Table::TableInfo));
        if (tabHandle->tableInfo.fieldNumber <= 0)
        {
            return CorruptedFile;
        }
        tabHandle->pFieldStruct = (FieldStruct *)calloc (tabHandle->tableInfo.fieldNumber, sizeof (FieldStruct));
        if (!tabHandle->pFieldStruct)
        {
            return CantReadData;
        }
        READ_DATA (tabHandle->pFieldStruct, sizeof (FieldStruct) * tabHandle->tableInfo.fieldNumber);
        return OK;
    }
    
    static enum Errors AllocateBuffers (struct Table * tabHandle)
    {
        int i;
        if (!tabHandle->pFieldStruct)
        {
            return BadHandle;
        }
        for (i = 0; i < tabHandle->tableInfo.fieldNumber; i++)
        {
            tabHandle->pFieldStruct[i].pNewValue = (char *)malloc(tabHandle->pFieldStruct[i].len);
            tabHandle->pFieldStruct[i].pEditValue = (char *)malloc(tabHandle->pFieldStruct[i].len);
            if (!tabHandle->pFieldStruct[i].pNewValue || !tabHandle->pFieldStruct[i].pEditValue)
            {
                return CantCreateHandle;
            }
        }
        return OK;
    }
    
    static enum Errors AddRecToDeleted (struct Table * tabHandle)
    {
        static unsigned long DELETE_MARK = ~0;
        // insert record to the deleted list
        MOVE_POS (tabHandle->currentPos);
        WRITE_DATA (&DELETE_MARK, sizeof DELETE_MARK);
        WRITE_DATA(&tabHandle->tableInfo.firstDeletedOffset, sizeof(tabHandle->tableInfo.firstDeletedOffset));
        tabHandle->tableInfo.firstDeletedOffset = tabHandle->currentPos;
        tabHandle->tableInfo.recordNumber--;
        // modify prev and next links
        if (tabHandle->links.prevOffset == -1)
        {
            // first record is deleted
            tabHandle->tableInfo.firstRecordOffset = tabHandle->links.nextOffset;
            if (tabHandle->tableInfo.recordNumber == 0)
            {
                tabHandle->tableInfo.firstRecordOffset = -1; // no more records
                tabHandle->tableInfo.lastRecordOffset = 0; // no more records
            }
        }
        else
        {
            MOVE_POS(tabHandle->links.prevOffset + sizeof(tabHandle->links.prevOffset));
            WRITE_DATA(&tabHandle->links.nextOffset, sizeof(tabHandle->links.nextOffset));
        }
        if (tabHandle->links.nextOffset == 0)
        {
            // last record is deleted
            tabHandle->tableInfo.lastRecordOffset = tabHandle->links.prevOffset;
            if (tabHandle->tableInfo.recordNumber == 0)
            {
                tabHandle->tableInfo.firstRecordOffset = -1; // no more records
                tabHandle->tableInfo.lastRecordOffset = 0; // no more records
            }
        }
        else
        {
            MOVE_POS(tabHandle->links.nextOffset);
            WRITE_DATA(&tabHandle->links.prevOffset, sizeof(tabHandle->links.prevOffset));
        }
        return OK;
    }
};

//
//class Xception
//{
//public:
//
//    std::string Message;
//    virtual void PrintMessage ();
//    Xception () {}
//    Xception ( const std::string& aMessage ) { Message = aMessage; }
//    Xception ( const Xception& xception ) { Message = xception.Message; }
//    virtual ~Xception () {}
//};
//
//class IField
//{
//public:
//    enum Type { TEXT, LONG };
//    virtual Type OfType () = 0;
//    virtual std::string& Text () = 0;
//    virtual long& Long () = 0;
//};
//
//class ITextField: public IField
//{
//    std::string text;
//public:
//    long& Long () override
//    {
//        throw Xception ();
//    }
//    std::string& Text () override
//    {
//        return text;
//    }
//};
//
//class ILongField: public IField
//{
//public:
//    virtual std::string& Text  ()
//    {
//        throw Xception ();
//    }
//
//};
//
//class ITableStruct
//{
//public:
//    virtual ITableStruct*AddText (const std::string& Name, int Length)=0;
//    virtual ITableStruct*AddLong (const std::string& Name)=0;
//    virtual ITableStruct*SetName (const std::string& Name)=0;
//};
//
//class ITable
//{
//public:
//    static ITable*Create (ITableStruct*TableStruct);
//    static ITableStruct*CreateTableStruct ();
//    static void Drop (const std::string& Name);
//    static ITable*Open (const std::string& Name);
//    virtual void Add () = 0;
//    virtual void Delete () = 0;
//    virtual void Drop () = 0;
//    virtual IField*Getfield (const std::string& Name) = 0;
//    virtual bool ReadFirst () = 0;
//    virtual bool ReadNext () = 0;
//    virtual void Update () = 0;
//    virtual ~ITable () {};
//};
//
// ITableStruct:: ITableStruct*AddText (const std::string& Name, int Length)
//{
//
//};
#endif /* Server_hpp */
