//
//  Server.cpp
//  SQL_server
//
//  Created by Дарья on 06.04.2021.
//

#include "Server.hpp"

std::string FILE_SIGNATURE = "DariaFile~~~";

std::string ErrorText[]=
           { "Success.",
             "Can't create table.",
             "Can't open table.",
             "Field not found.",
             "Bad table handle",
             "Wrong arguments",
             "Can't set file position",
             "File write error",
             "File read error",
             "Table data corrupted",
             "Can't create table handle",
             "Can't delete or open read-only file",
             "Illegal file name",
             "Can't delete table",
             "File data corrupted",
             "Bad File Position",
             "Wrong field type",
             "Text value exceeds field length",
             "Current record is not edited",
          };
