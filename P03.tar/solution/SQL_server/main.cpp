//
//  main.cpp
//  SQL_server
//
//  Created by Дарья on 06.04.2021.
//

#include <iostream>
#ifndef Server_hpp
#include "Server.hpp"
#endif

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    
    std::fstream r;
    r.open("/Users/Dara/Importamt/4.txt", std::fstream::out);
    r.close();
    
    TableStruct ts;
    ts.numOfFields = 1;
    ts.fieldsDef = new FieldDef;
    ts.fieldsDef->type = Text;
    ts.fieldsDef->name = "lolol";
    ts.fieldsDef->len = 6;
    
    TableHandle::createTable("/Users/Dara/Documents/C++/SQL_server/SQL_server/1.txt", &ts);
    THandle *tableHandle = new THandle;
    enum Errors k = TableHandle::openTable("/Users/Dara/Documents/C++/SQL_server/SQL_server/1.txt", tableHandle);
    std::cout << ErrorText[k];
    TableHandle::putTextNew(*tableHandle, "lolol", "1234");
    TableHandle::closeTable(*tableHandle);
    TableHandle::deleteTable("/Users/Dara/Documents/C++/SQL_server/SQL_server/1.tab");
    //delete tableHandle;
    return 0;
}
