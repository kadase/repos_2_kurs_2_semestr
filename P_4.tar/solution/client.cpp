#include <iostream>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#define ADDRESS "mysocket" // адрес для связи

#define MaxFieldNameLen 200
int main ()
{
    int s,len;
    FILE *fp;
    struct sockaddr_un sa;
    // получаем свой сокет-дескриптор:
    if ((s = socket (AF_UNIX, SOCK_STREAM, 0)) < 0)
    {
        perror ("client: socket");
        return 1;
    }
    // создаем адрес, по которому будем связываться с сервером:
    sa.sun_family = AF_UNIX;
    strcpy (sa.sun_path, ADDRESS);
    // пытаемся связаться с сервером:
    len = sizeof ( sa.sun_family) + strlen ( sa.sun_path);
    if ( connect ( s, (struct sockaddr *)&sa, len) < 0 )
    {
        perror ("client: connect");
        return 1;
    }
    /*--------------------------------------------- */
    // читаем сообщения сервера, пишем серверу:
    fp = fdopen (s, "r");

    //c = fgetc (fp);
    while(1)
    {
        std::cout<<"Enter command\n";
        char cmd[MaxFieldNameLen];
        fgets(cmd, MaxFieldNameLen, stdin);
        char len_name = strlen(cmd) + 1;
        send (s, &len_name, sizeof(char), 0);
        send (s, cmd, strlen(cmd), 0);
    }
    fclose (fp);
    return 0;
}
