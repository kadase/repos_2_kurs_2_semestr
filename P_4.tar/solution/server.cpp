#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

#include "analyzer.cpp"

#include "ServerFunctions.hpp"


#define ADDRESS "mysocket" // адрес для связи
int main ()
{
    //printf("%s\n", "SERVER");
    FILE * fp;
    int d, d1, len, ca_len;
    struct sockaddr_un sa, ca;
    // получаем свой сокет-дескриптор:
    if((d = socket (AF_UNIX, SOCK_STREAM, 0)) < 0)
    {
        perror ("client: socket");
        return 1;
    }
    // создаем адрес, c которым будут связываться клиенты
    sa.sun_family = AF_UNIX;
    strcpy (sa.sun_path, ADDRESS);
    // связываем адрес с сокетом;
    // уничтожаем файл с именем ADDRESS, если он существует, // для того, чтобы вызов bind завершился успешно
    unlink (ADDRESS);
    len = sizeof ( sa.sun_family) + strlen (sa.sun_path);
    if ( bind ( d, (struct sockaddr *)&sa, len) < 0 )
    {
        perror ("server: bind");
        return 1;;
    }
    // слушаем запросы на сокет
    if (listen (d,5) < 0)
    {
        perror ("server: listen");
        return 1;;
    }
    // связываемся с клиентом через неименованный сокет с дескриптором d1:
    ca_len = sizeof ca;
    if (( d1 = accept( d, (struct sockaddr *)&ca, (socklen_t *)&ca_len)) < 0 )
    {
        perror ("server: accept");
        return 1;
    }
    /* ------------------------------------------ */
    // читаем запросы клиента, пишем клиенту:
    printf("%s\n", "SERVER read");
    fp = fdopen (d1, "r");
    while(1)
    {
        char str[MaxFieldNameLen];
        char len_name = fgetc(fp);
        fgets(str, len_name, fp);
        Parser p(str);
        p.analyze();
    }
    fclose (fp);
    return 0;
}
