#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <stack>

#include "ServerFunctions.hpp"

enum type_of_lex
{
    LEX_COMMA, // ,
    LEX_APOST, // '
    LEX_LPAREN, // (
    LEX_RPAREN, // )
    LEX_ASTER, // *
    LEX_PERSENT, // %
    LEX_EQ, // =
    LEX_LTR, // <
    LEX_GTR, // >
    LEX_PLUS, // +
    LEX_MINUS, // -
    LEX_SLASH, // /
    LEX_NEQ,
    LEX_NULL,
    LEX_SELECT,
    LEX_UPDATE,
    LEX_INSERT,
    LEX_DELETE,
    LEX_CREATE,
    LEX_DROP,
    LEX_WHERE,
    LEX_NUM,
    LEX_ID,
    LEX_SYM,
    LEX_STR,
    LEX_MOREQ,
    LEX_LOREQ,
    LEX_SEMICOLON,
    LEX_FROM,
    LEX_TEXT,
    LEX_LONG,
    LEX_INTO,
    LEX_SET,
    LEX_LIKE,
    LEX_AND,
    LEX_OR,
    LEX_NOT,
    LEX_TABLE,
    LEX_IN,
    LEX_LBRACKET, //[
    LEX_RBRACKET, //]
    LEX_ID_TEXT,
    LEX_ID_LONG
};

std::string names[]
{
    "LEX_COMMA", // ,
    "LEX_APOST", // '
    "LEX_LPAREN", // (
    "LEX_RPAREN", // )
    "LEX_ASTER", // *
    "LEX_PERSENT", // %
    "LEX_EQ", // =
    "LEX_LTR", // <
    "LEX_GTR", // >
    "LEX_PLUS", // +
    "LEX_MINUS", // -
    "LEX_SLASH", // /
    "LEX_NEQ",
    "LEX_NULL",
    "LEX_SELECT",
    "LEX_UPDATE",
    "LEX_INSERT",
    "LEX_DELETE",
    "LEX_CREATE",
    "LEX_DROP",
    "LEX_WHERE",
    "LEX_NUM",
    "LEX_ID",
    "LEX_SYM",
    "LEX_STR",
    "LEX_MOREQ",
    "LEX_LOREQ",
    "LEX_SEMICOLON",
    "LEX_FROM",
    "LEX_TEXT",
    "LEX_LONG",
    "LEX_INTO",
    "LEX_SET",
    "LEX_LIKE",
    "LEX_AND",
    "LEX_OR",
    "LEX_NOT",
    "LEX_TABLE",
    "LEX_IN",
    "LEX_LBRACKET", //[
    "LEX_RBRACKET", //]
    "LEX_ID_TEXT",
    "LEX_ID_LONG"
};

class Lex
{
    type_of_lex t_lex;
    int v_lex;
public:
    Lex ( type_of_lex t = LEX_NULL, int v = 0)
    {
        t_lex = t;
        v_lex = v;
    }
    type_of_lex get_type ()
    {
        return t_lex;
    }
    int get_value ()
    {
        return v_lex;
    }
    friend std::ostream& operator << ( std::ostream &s, Lex l )
    {
        s << '(' << names[l.t_lex] << ',' << l.v_lex << ");";
        return s;
    }
};

class Ident
{
    char * name;
    bool declare;
    type_of_lex type;
    bool assign;
    int value;
public:
    Ident ()
    {
        declare = false;
        assign = false;
    }
    char *get_name ()
    {
        return name;
    }
    void put_name (const char *n)
    {
        name = new char [ strlen(n) + 1 ];
        strcpy ( name, n );
    }
    bool get_declare ()
    {
        return declare;
    }
    void put_declare ()
    {
        declare = true;
    }
 
    type_of_lex get_type ()
    {
        return type;
    }
    void put_type ( type_of_lex t )
    {
        type = t;
    }
    bool get_assign ()
    {
        return assign;
    }
    void put_assign ()
    {
        assign = true;
    }
    int get_value ()
    {
        return value;
    }
    void put_value (int v)
    {
        value = v;
    }
};

class tabl_ident
{
    Ident * p;
    int  size;
    int top;
public:
    tabl_ident ( int max_size )
    {
        p = new Ident[size=max_size];
        top = 1;
    }
    ~tabl_ident ()
    {
        delete []p;
    }
    Ident& operator[] ( int k )
    {
        return p[k];
    }
    int put ( const char *buf );
};
int tabl_ident::put ( const char *buf )
{
    for ( int j=1; j<top; ++j )
        if ( !strcmp(buf, p[j].get_name()) )
                return j;
    p[top].put_name(buf);
    ++top;
    return top-1;
}

class Scanner
{
    enum state { H, IDENT, NUMB, SYMB, ALE, FALS, NEQ, STR };
    static const char* TW[];
    static type_of_lex words[];
    static const char* TD[];
    static type_of_lex dlms[];
    state CS;
    // FILE * fp;
    char c;
    char buf[80];
    int buf_top;
    void clear ()
    {
        buf_top = 0;
        for ( int j = 0; j < 80; ++j )
        buf[j] = '\0';
    }
    void add ()
    {
        buf [ buf_top ++ ] = c;
    }
    int look ( const char * bbuf, const char** list )
    {
        int ii = 0;
        while ( list[ii] )
        {
            if ( !strcmp(bbuf, list[ii]) ) return ii;
            ++ii;
        }
        return 0;
    }
    void gc ()
    {
        c = str[i];
        i++;
    }

    int i = 0;
    char str[200];
public:
    Lex get_lex ();
    Scanner ( const char * strrr )
    {
        strcpy(str, strrr);
        gc();
    }
    
    char get_c()
    {
        return c;
    }
};

const char* Scanner:: TD[] =
{
    "",// 0
    "%", //1
    "'", //2
    ",", //3
    "(", //4
    ")", //5
    "=", //6
    "<", //7
    ">", // 8
    "+", // 9
    "-", // 10
    "*", // 11
    "/", // 12
    "<=", // 13
    "!=", // 14
    ">=", // 15
    ";", // 16
    "[", // 17
    "]", // 18
    NULL
};

type_of_lex Scanner::dlms[] =
{
    LEX_NULL,
    LEX_PERSENT, // %
    LEX_APOST, // '
    LEX_COMMA, // ,
    LEX_LPAREN, // (
    LEX_RPAREN, // )
    LEX_EQ, // =
    LEX_LTR, // <
    LEX_GTR, // >
    LEX_PLUS, // +
    LEX_MINUS, // -
    LEX_ASTER, // *
    LEX_SLASH, // /
    LEX_LOREQ, // <=
    LEX_NEQ, // !=
    LEX_MOREQ,// >=
    LEX_SEMICOLON, //;
    LEX_LBRACKET, //[
    LEX_RBRACKET //]
};


const char* Scanner::TW[] =
{
    "", // 0
    "SELECT", //1
    "UPDATE", //2
    "INSERT", //3
    "DELETE", //4
    "CREATE", //5
    "DROP", //6
    "WHERE", //7
    "FROM", //8
    "TEXT", //9
    "LONG", //10
    "INTO", //11
    "SET", //12
    "LIKE", //13
    "AND", //14
    "OR", //15
    "NOT", //16
    "TABLE", //17
    "IN", //18
    NULL
};

type_of_lex Scanner::words[] =
{
    LEX_NULL, //0
    LEX_SELECT, //1
    LEX_UPDATE, //2
    LEX_INSERT, //3
    LEX_DELETE, //4
    LEX_CREATE, //5
    LEX_DROP, //6
    LEX_WHERE, //7
    LEX_FROM, //8
    LEX_TEXT, //9
    LEX_LONG, //10
    LEX_INTO, //11
    LEX_SET, //12
    LEX_LIKE, //13
    LEX_AND, //14
    LEX_OR, //15
    LEX_NOT, //16
    LEX_TABLE, //17
    LEX_IN //18  
};


tabl_ident TID(100);

Lex Scanner::get_lex ()
{
    int d = 0, j;
    CS = H;
    do
    {
    switch (CS)
    {
        case H:
            if (c ==' ' || c =='\n' || c=='\r' || c =='\t')
                gc ();
            else if ( isalpha(c) )
            {
                clear ();
                add ();
                gc ();
                CS = IDENT;
            }
            else if ( isdigit(c) )
            {
                d = c - '0';
                gc ();
                CS = NUMB;
            }
            else if ( c== '(' || c== ')' || c== '*' || c== '/' || c== '%' || c== '=' ||
                     c== '+' || c== '-' || c== ',' || c == ';')
            {
                clear ();
                add ();
                gc ();
                CS = SYMB;
            }
            else if ( c == '<' || c == '>')
            {
                clear ();
                add ();
                gc ();
                CS = ALE;
            }
            else if ( c == '!' )
            {
                clear ();
                add ();
                gc ();
                CS = NEQ;
            }
            else if (c == '\'')
            {
                clear ();
                gc ();
                CS = STR;
            }
            else
            CS = FALS;
            break;
        case IDENT:
            if ( isalpha(c) || isdigit(c) )
            {
                add ();
                gc ();
            }
            else
                if ((j = look (buf, TW) ))
                    return Lex (words[j], j);
                else
                {
                    j = TID.put(buf);
                    return Lex (LEX_ID, j);
                }
            break;
        case SYMB:
            j = look(buf, TD);
            return Lex(dlms[j], j);
        case STR:
            while (c != '\'')
            {
                add ();
                gc ();
            }
            gc();
            j = TID.put(buf);
            return Lex (LEX_STR, j);
        case NUMB:
            if ( isdigit(c) )
            {
                d = d * 10 + (c - '0');
                gc();
            }
            else
                return Lex ( LEX_NUM, d );
            break;
        case ALE:
            if ( c == '=' )
            {
                add ();
                gc ();
                j = look ( buf, TD );
                return Lex ( dlms[j], j );
            }
            else
            {
                j = look (buf, TD);
                return Lex ( dlms[j], j);
            }
            break;
        case NEQ:
            if ( c == '=' )
            {
                add ();
                gc ();
                j = look( buf, TD );
                return Lex ( LEX_NEQ, j );
            }
            else
                throw '!';
            break;
        case FALS:
            if (c == EOF)
            {
                return Lex(LEX_NULL, 0);
            }
            else
                throw c;
            break;
        } // end switch
    }
    while ( true );
}

class Parser
{
    Lex cur_lex; //current lexeme
    type_of_lex c_type;
    int c_val;
    Scanner scan;
    void SQL();
    void S();
    void A();
    void B();
    void I();
    void F();
    void G();
    void U();
    void D();
    void C();
    void LIST();
    void T_F();
    void R();
    void DROP();
    void WHE();
    void W();
    void DDD();
    void XXX();
    void L_C();
    void K();
    void L();
    void EXP();
    void LONG_EXP();
    void PP();
    void PM();
    void LONG_SLAG();
    void MM();
    void MD();
    void LONG_MNO();
    void TEXT_EXP();
    void REP();
    void TEXT_OTN();
    void QWER();
    void CMP();
    void check_id ();
    void gl () // get next lexeme
    {
        cur_lex = scan.get_lex();
        c_type = cur_lex.get_type();
        c_val = cur_lex.get_value();
    }

public:
    Parser ( const char *str) : scan (str) //prog (1000)
    {}
    void analyze(); // анализатор с действиями
};

size_t count_f;
THandle *tableHandle = NULL;

TableStruct ts;
FieldDef* tmp = NULL;

int ch = 1;
int flag = 0;
char** mas_id = new char*[ch];

void Parser::analyze ()
{
    gl ();
    SQL ();
    std::cout << std::endl << "Yes!!!" << std::endl;
}

//<SQL> -> SELECT <S> | INSERT <I> | UPDATE <U> | DELETE<D> | CREATE<C> | DROP<DROP>

void Parser::SQL()
{
    if (c_type == LEX_SELECT)
    {
        gl();
        S();
    }
    else if (c_type == LEX_INSERT)
    {
        gl();
        I();
    }
    else if (c_type == LEX_UPDATE)
    {
        gl();
        U();
    }
    else if (c_type == LEX_DELETE)
    {
        gl();
        D();
    }
    else if (c_type == LEX_CREATE)
    {
        gl();
        C();
    }
    else if (c_type == LEX_DROP)
    {
        gl();
        DROP();
    }
    else
    {
        throw cur_lex;
    }
    
}

//SELeCT
//<S> -> <A> FROM ID <WHE>
void Parser::S()
{
    A();
    if (c_type == LEX_FROM)
    {
        gl();
    }
    else
    {
        throw cur_lex;
    }
    if (c_type == LEX_ID)
    {
        tableHandle = new THandle;
        TableHandle::openTable(TID[cur_lex.get_value()].get_name(), tableHandle);
        TableHandle::moveLast(*tableHandle);
        if (flag == 1)
        {
            ch = (*tableHandle)->tableInfo.recordNumber;
        }
        for (int i = 0; i <= ch; i++)
        {
            TableHandle::GetCurrentRecord (*tableHandle);
            std::cout<<(*tableHandle)->pFieldStruct[i].pNewValue<<" ";
            TableHandle::moveNext(*tableHandle);
        }
        TableHandle::closeTable(*tableHandle);
        gl();
    }
    else
    {
        throw cur_lex;
    }
    WHE();
}

//<A> -> ID <B> | *
void Parser::A()
{
    if (c_type == LEX_ID)
    {
        mas_id[ch-1] = TID[cur_lex.get_value()].get_name();
        gl();
        B();
    }
    else if (c_type == LEX_ASTER)
    {
        flag = 1;
        gl();
    }
    else
    {
        throw cur_lex;
    }
}

//<B> -> ,ID <B> | eps
void Parser::B()
{
    if (c_type == LEX_COMMA)
    {
        gl();
        if (c_type == LEX_ID)
        {
            ch++;
            mas_id = (char**)realloc(mas_id, ch * sizeof(char*));
            mas_id[ch-1] = TID[cur_lex.get_value()].get_name();
            gl();
            B();
        }
    }
}

//INSERT
//<I> -> INTO ID ( <F> )
void Parser::I()
{
    if (c_type == LEX_INTO)
    {
        gl();
    }
    else
    {
        throw cur_lex;
    }
    if (c_type == LEX_ID)
    {
        tableHandle = new THandle;
        TableHandle::openTable(TID[cur_lex.get_value()].get_name(), tableHandle);
        gl();
    }
    else
    {
        throw cur_lex;
    }
    if (c_type == LEX_LPAREN)
    {
        gl();
        count_f = 0;
        F();
    }
    else
    {
        throw cur_lex;
    }
    if (c_type == LEX_RPAREN)
    {
        TableHandle::insertNew(*tableHandle);
        TableHandle::closeTable(*tableHandle);
        gl();
    }
    else
    {
        throw cur_lex;
    }
}

//<F> -> STR <G>| NUM <G>
void Parser::F()
{
    if (c_type == LEX_STR)
    {
        TableHandle::putTextNew(*tableHandle, (*tableHandle)->pFieldStruct[count_f].fieldName, 
            TID[cur_lex.get_value()].get_name());
        gl();
    }
    else if (c_type == LEX_NUM)
    {
        TableHandle::putLongNew(*tableHandle, (*tableHandle)->pFieldStruct[count_f].fieldName, 
            cur_lex.get_value());
        gl();
    }
    else
    {
        throw cur_lex;
    }
    count_f++;
    G();
}

//<G> -> ,<F> | eps
void Parser::G()
{
    if (c_type == LEX_COMMA)
    {
        gl();
        F();
    }
}

//UPDATE
//<U> ->  ID SET ID = <EXP> <WHE>
void Parser::U()
{
    if (c_type == LEX_ID)
    {
        gl();
    }
    else
    {
        throw cur_lex;
    }
    if (c_type == LEX_SET)
    {
        gl();
    }
    else
    {
        throw cur_lex;
    }
    if (c_type == LEX_ID)
    {
        gl();
    }
    else
    {
        throw cur_lex;
    }
    if (c_type == LEX_EQ)
    {
        gl();
    }
    else
    {
        throw cur_lex;
    }
    EXP();
    WHE();
}

//DELete
//<D> ->  FROM ID <WHE>
void Parser::D()
{
    if (c_type == LEX_FROM)
    {
        gl();
    }
    else
    {
        throw cur_lex;
    }
    if (c_type == LEX_ID)
    {
        gl();
    }
    else
    {
        throw cur_lex;
    }
    WHE();
}

//CREATE
////<C> ->  TABLE ID ( <LIST> )
void Parser::C()
{
    char table_name[200];
    if (c_type == LEX_TABLE)
    {
        gl();
    }
    else
    {
        throw cur_lex;
    }
    if (c_type == LEX_ID)
    {
        //std::cout << cur_lex.get_value();
        strcpy(table_name, TID[cur_lex.get_value()].get_name());
        //std::cout << "copy\n";
        gl();
    }
    else
    {
        throw cur_lex;
    }
    if (c_type == LEX_LPAREN)
    {
        gl();
        count_f = 0;
        LIST();
    }
    else
    {
        throw cur_lex;
    }
    if (c_type == LEX_RPAREN)
    {
        TableHandle::createTable(table_name, &ts);
        gl();
        
    }
    else
    {
        throw cur_lex;
    }
    
}

//<LIST> -> ID <T_F> <R>
void Parser::LIST()
{
    if (c_type == LEX_ID)
    {
        tmp = new FieldDef[count_f + 1];
        if (count_f > 0)
        {
            for (int i = 0; i < count_f; i++)
            { 
                tmp[i].name = ts.fieldsDef[i].name;
                tmp[i].type = ts.fieldsDef[i].type;
                tmp[i].len = ts.fieldsDef[i].len;
            }
        }
        tmp[count_f].name = TID[cur_lex.get_value()].get_name();
        gl();
    }
    else
    {
        throw cur_lex;
    }
    T_F();
    if (ts.fieldsDef)
    {
        delete [] ts.fieldsDef;
    }
    ts.fieldsDef = tmp;   
    count_f++;
    ts.numOfFields = count_f; 
    R(); 
}

//<T_F> -> TEXT ( NUM ) | LONG 
void Parser::T_F()
{
    
    if (c_type == LEX_TEXT)
    {
        gl();
        if (c_type == LEX_LPAREN)
        {
            gl();
        }
        else
        {
            throw cur_lex;
        }
        if (c_type == LEX_NUM)
        {
            tmp[count_f].type = Text;
            tmp[count_f].len = cur_lex.get_value();
            gl();
        }
        else
        {
            throw cur_lex;
        }
        if (c_type == LEX_RPAREN)
        {
            gl();
        }
        else
        {
            throw cur_lex;
        }
    }
    else if (c_type == LEX_LONG)
    {
        tmp[count_f].type = Long;
        gl();
    }
    else
    {
        throw cur_lex;
    }   
    
}

//<R> -> ,<LIST> | eps
void Parser::R()
{
    if (c_type == LEX_COMMA)
    {
        gl();
        LIST();
    }
}

//DROP
//<DROP> ->  TABLE ID
void Parser::DROP()
{
    if (c_type == LEX_TABLE)
    {
        gl();
    }
    else
    {
        throw cur_lex;
    }
    try
    {
        if (c_type == LEX_ID)
    {
        
        int k =  TableHandle::deleteTable(TID[cur_lex.get_value()].get_name());
        std::cout <<"\n" << ErrorText[k];
    }
    else
    {
        throw cur_lex;
    }

    }
    catch (...)
    {
        std::cout <<"--------\n" ;
        
    }  
}

//WHERE
//<WHE> -> WHERE <W>
void Parser::WHE()
{
    if (c_type == LEX_WHERE)
    {
        gl();
        W();
    }
    else
    {
        throw cur_lex;
    }
}

//<W> ->  ID <DDD> | <Long_EXP>
void Parser::W()
{
    if (c_type == LEX_ID)
    {
        gl();
        DDD();
    }
    else
    {
        LONG_EXP();
    }
}

//<DDD> -> NOT <XXX> | <XXX>
void Parser::DDD()
{
    if (c_type == LEX_NOT)
    {
        gl();
        XXX();
    }
    else
    {
        XXX();
    }
}

//<XXX> ->  LIKE STR | IN ( <L_C> )
void Parser::XXX()
{
    if (c_type == LEX_LIKE)
    {
        gl();
        if (c_type == LEX_STR)
        {
            gl();
        }
        else
        {
            throw cur_lex;
        }
    }
    else if (c_type == LEX_IN)
    {
        gl();
        if (c_type == LEX_LPAREN)
        {
            gl();
        }
        else
        {
            throw cur_lex;
        }
        L_C();
        if (c_type == LEX_RPAREN)
        {
            gl();
        }
        else
        {
            throw cur_lex;
        }
    }
    else
    {
        throw cur_lex;
    }
}

//<L_C> -> STR <K> | NUM <L>
void Parser::L_C()
{
    if (c_type == LEX_STR)
    {
        gl();
        K();
    }
    else if (c_type == LEX_NUM)
    {
        gl();
        L();
    }
    else
    {
        throw cur_lex;
    }
}

//<K> -> , STR <K> | eps
void Parser::K()
{
    if (c_type == LEX_COMMA)
    {
        gl();
        if (c_type == LEX_STR)
        {
            gl();
        }
        else
        {
            throw cur_lex;
        }
        K();
    }
}

//<L> -> , NUM <L> | eps
void Parser::L()
{
    if (c_type == LEX_COMMA)
    {
        gl();
        if (c_type == LEX_NUM)
        {
            gl();
        }
        else
        {
            throw cur_lex;
        }
        L();
    }
}

//<EXP> ->  STR| <LONG_EXP>
void Parser::EXP()
{
    if (c_type == LEX_STR)
    {
        gl();
    }
    else
    {
        LONG_EXP();
    }
}

//<LONG_EXP> ->  <LONG_SLAG> <PP>
void Parser::LONG_EXP()
{
    LONG_SLAG();
    PP();
}

//<PP> -> + <Long_EXP> | - <Long_EXP> | OR <Long_EXP> |eps
void Parser::PP()
{
    if (c_type == LEX_PLUS || c_type == LEX_MINUS || c_type == LEX_OR)
    {
        gl();
        LONG_EXP();
    }
}


//<LONG_SLAG> ->  <LONG_MNO> <MM>
void Parser::LONG_SLAG()
{
    LONG_MNO();
    MM();
}

//<MM> -> * <Long_SLAG> | / <Long_SLAG> | % <Long_SLAG> | AND <Long_SLAG> | eps
void Parser::MM()
{
    if (c_type == LEX_ASTER || c_type == LEX_SLASH || c_type == LEX_PERSENT || c_type == LEX_AND)
    {
        gl();
        LONG_SLAG();
    }
}

//<LONG_MNO> -> NOT <LONG_MNO> | ID_LONG | NUM | ( <REP>
void Parser::LONG_MNO()
{
    if (c_type == LEX_NOT)
    {
        gl();
        LONG_MNO();
    }
    else if (c_type == LEX_ID)
    {
        gl();
    }
    else if (c_type == LEX_NUM)
    {
        gl();
    }
    else if (c_type == LEX_LPAREN)
    {
        gl();
        REP();
    }
    else
    {
        throw cur_lex;
    }
}

//<TEXT_EXP> -> ID_TEXT | STR
void Parser::TEXT_EXP()
{
    if (c_type == LEX_ID_TEXT)
    {
        gl();
    }
    else if (c_type == LEX_STR)
    {
        gl();
    }
    else
    {
        throw cur_lex;
    }
}

//<REP> -> <LONG_EXP> <QWER> | ID_TEXT <TEXT_OTN> | STR <TEXT_OTN>
void Parser::REP()
{
    LONG_EXP();
    gl();
    QWER();
    if (c_type == LEX_ID_TEXT)
    {
        gl();
        TEXT_OTN();
    }
    else if (c_type == LEX_STR)
    {
        gl();
        TEXT_OTN();
    }
    else
    {
        throw cur_lex;
    }
}

//<TEXT_OTN> -> <CMP> <TEXT_EXP> )
void Parser::TEXT_OTN()
{
    CMP();
    TEXT_EXP();
    if (c_type == LEX_RPAREN)
    {
        gl();
    }
    else
    {
        throw cur_lex;
    }
}

//<QWER> -> ) | <CMP> <LONG_EXP> )
void Parser::QWER()
{
    if (c_type == LEX_LPAREN)
    {
        gl();
    }
    else
    {
        CMP();//gl()???
        LONG_EXP();//gl()???
        if (c_type == LEX_RPAREN)
        {
            gl();
        }
        else
        {
            throw cur_lex;
        }
    }
}

//<CMP> -> = | > | < | >= | <= | !=
void Parser::CMP()
{
    if (c_type == LEX_EQ)
    {
        gl();
    }
    else if (c_type == LEX_GTR)
    {
        gl();
    }
    else if (c_type == LEX_LTR)
    {
        gl();
    }
    else if (c_type == LEX_MOREQ)
    {
        gl();
    }
    else if (c_type == LEX_LOREQ)
    {
        gl();
    }
    else if (c_type == LEX_NEQ)
    {
        gl();
    }
    else
    {
        throw cur_lex;
    }
}
